# Accès serveur — application Android

Cette application ouvre uniquement `http://10.216.142.89:5000` dans une WebView.
Les liens de navigation vers une autre adresse sont bloqués.

## Générer l'APK
1. Installez Android Studio sur Windows.
2. Décompressez ce dossier.
3. Dans Android Studio, choisissez **Open** et sélectionnez le dossier `AccesServeurAPK`.
4. Laissez Gradle synchroniser le projet (JDK 17 recommandé).
5. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. L'APK de test se trouvera normalement dans `app/build/outputs/apk/debug/app-debug.apk`.

## Installer sur le téléphone
Transférez `app-debug.apk` sur le téléphone Android et ouvrez-le. Autorisez l'installation depuis cette source si Android le demande.

## Important
- Le téléphone doit pouvoir joindre `10.216.142.89` sur le port `5000` : généralement, il doit être sur le même Wi-Fi ou connecté au VPN/réseau de l'entreprise.
- L'adresse `10.x.x.x` est une adresse privée/interne, elle ne sera normalement pas accessible depuis Internet public.
- Le serveur doit rester démarré et écouter sur une interface accessible depuis le téléphone, pas uniquement sur `127.0.0.1`.
- Le projet utilise HTTP sans chiffrement, adapté à un réseau local de confiance. Pour des données sensibles, préférez HTTPS.
